<?php
    function myFunction()
    {
        return true;
    }
?>